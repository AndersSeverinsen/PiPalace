#!/usr/bin/env python
import datetime
import time
import RPi.GPIO as GPIO
import board
from adafruit_ht16k33.segments import Seg14x4

i2c = board.I2C()
display = Seg14x4(i2c)

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
Button1 = 27
GPIO.setup(Button1, GPIO.IN, pull_up_down = GPIO.PUD_UP)

# clear display
display.fill(0)

def clock():
    # get system time
    now = datetime.datetime.now()
    hour = now.hour
    minute = now.minute
    second = now.second

    # Toggle colon when displaying time
    if second % 2:
        # setup HH:MM for display and print it
        clock = '%02d.%02d' % (hour,minute)          # concat hour + minute, add leading zeros
        display.print(clock)
    else:
        # setup HH:MM for display and print it
        clock = '%02d%02d' % (hour,minute)          # concat hour + minute, add leading zeros
        display.print(clock)

    time.sleep(0.5)

while (True):
    clock()

    if GPIO.input(Button1)==0:
        print("Button 1 Was Pressed:")